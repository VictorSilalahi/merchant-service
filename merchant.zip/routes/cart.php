<?php

use Tuupola\Base62;
use Firebase\JWT\JWT;


$app->post("/v1/merchant/register", function ($request, $response, $args) 
{

});