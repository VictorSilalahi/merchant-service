<?php

namespace Exception;

class FileUploadErrorException extends \Exception
{
}
